var sum =0;
var array_1 =[1,2,2];
var array_2 =[2,3,4];
sum = array_1[index]+array_2[index];
console.log(sum);
