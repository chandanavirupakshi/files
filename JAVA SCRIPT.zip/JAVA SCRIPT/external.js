document.write("<h1>welcome to javascript</h1>");
