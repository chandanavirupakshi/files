var x,y,z;
for(x=1; x <=6; x++){
    for(y=1; y<x ; y++){
        z=z+("*");
    }
    console.log(z);
    z="";
}
