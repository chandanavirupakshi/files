var students = [['David', 80], ['vinoth', 77], ['nishitha', 85], ['Divya', 95], ['Thomas', 68]];

var Avgmarks = 0;

for (var i = 0; i < students.length; i++) {

    Avgmarks +=students[i][1];

    var avg = (Avgmarks / students.length);

}

console.log("Average grade:" + (Avgmarks) / students.length);

if (avg < 60) {

    console.log("grade: F")

}

else if (avg < 70) {

    console.log("grade: D");

}

else if (avg < 80) {

    console.log("garde: c");



}

else if (avg < 90) {

    console.log("grade : B");

}

else if (avg < 100) {

    console.log("grade : A");

}