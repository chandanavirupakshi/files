for(var x=0; x<=15; x++){
    if(x === 0){
        console.log(x+ "is the even");
    }
    else if(x%2 === 0){
        console.log(x+ " is the even");
    }
    else{
        console.log(x+"is the odd");
    }
}