const array_1 = [2,3,4,5];
const array_2 = [4,3,3,1];
const Add = (array_1=[], array_2=[])=>{
    let sum=0;
    for(let i=0; i< array_1.length; i++){
        const product =(array_1[i]*array_2[i]);
        sum+=product;
    };
    return sum;
};
console.log(Add(array_1,array_2));

