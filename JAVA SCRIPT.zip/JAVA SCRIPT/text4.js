var x,y,z;
for(x=0; x=11; x++){
    for(y=0; y<x; y++){
         z=z+"#";
    }
    console.log(z);
    z='';
}